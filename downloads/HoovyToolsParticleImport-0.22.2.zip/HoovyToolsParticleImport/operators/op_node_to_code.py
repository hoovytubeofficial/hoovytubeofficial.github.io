# =============================================================================
#  operators/op_node_to_code.py  -  NODE TO CODE as a one-click operator
# =============================================================================
#
#  Wraps tools/gn_to_python.py. Select the effect's object (or open its group
#  in a Geometry Nodes editor), press the button: the rebuild script lands on
#  the clipboard AND in a '<group>__rebuild.py' Text block. For 600+ node
#  monsters the clipboard can truncate - run the Text block instead.
#
#  The module is reloaded on every run so edits to it take effect without
#  restarting Blender.
# =============================================================================

import importlib

import bpy
from bpy.types import Operator


class HTP_OT_NodeToCode(Operator):
    """Turn the selected HoovyTools effect into a .py that rebuilds it
anywhere

SELECT THE EFFECT'S OBJECT FIRST. You get a runnable script on the
clipboard and in a Text block: run it in an empty scene and the whole
thing comes back - objects, meshes, UVs, materials, node groups and every
modifier input.

TEXTURES TRAVEL WITH IT, embedded in the script, so whoever you hand it
to does not need your SFM install or your .vtf files.

Anything it cannot rebuild is reported, never dropped quietly."""
    bl_idname = "htp.node_to_code"
    bl_label = "Node to Code"
    bl_options = {"REGISTER"}

    def execute(self, context):
        from ..tools import gn_to_python
        importlib.reload(gn_to_python)

        # Refuse loudly instead of claiming a copy that never happened: an
        # empty scene used to still report "COPIED TO CLIPBOARD".
        try:
            tree = gn_to_python._active_tree()
        except Exception as exc:
            self.report({"ERROR"}, f"Node to Code failed to look for a group: {exc}")
            return {"CANCELLED"}

        if tree is None:
            self.report(
                {"ERROR"},
                "No geometry nodes found. Select the object carrying the "
                "effect's Geometry Nodes modifier, or open its group in a "
                "Geometry Nodes editor.")
            return {"CANCELLED"}

        try:
            result = gn_to_python.main()
        except Exception as exc:
            self.report({"ERROR"}, f"Node to Code failed: {exc}")
            print(f"[HT_PARTICLE]  Node to Code ERROR: {exc}")
            return {"CANCELLED"}

        if not result:
            self.report({"ERROR"},
                        "Node to Code produced nothing - see the console.")
            return {"CANCELLED"}

        self.report({"INFO"},
                    f"Node to Code: '{tree.name}' -> clipboard + Text block "
                    f"'{tree.name}__rebuild.py'")
        return {"FINISHED"}


CLASSES = (HTP_OT_NodeToCode,)
